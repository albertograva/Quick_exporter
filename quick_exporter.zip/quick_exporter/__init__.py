# -*- coding: utf-8 -*-
"""QuickExporter - esporta layer ritagliati/selezionati su una maschera."""


def classFactory(iface):  # noqa: N802
    from .plugin import QuickExporterPlugin
    return QuickExporterPlugin(iface)
