# -*- coding: utf-8 -*-
import os
from datetime import datetime

from qgis.PyQt.QtCore import Qt, QUrl, QCoreApplication
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QFormLayout, QGridLayout, QGroupBox,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMessageBox, QPlainTextEdit,
    QProgressBar, QPushButton, QRadioButton, QTreeWidget, QTreeWidgetItem,
    QVBoxLayout,
)
from qgis.core import (
    Qgis, QgsIconUtils, QgsProcessingFeedback, QgsProject, QgsRasterLayer,
    QgsSettings, QgsVectorLayer,
)
from qgis.gui import QgsFileWidget, QgsMapLayerComboBox, QgsProjectionSelectionWidget

from .exporter import (
    FORMATS, MODE_CLIP, MODE_SELECT, PRED_INTERSECT, PRED_WITHIN,
    ExportOptions, MaskExporter, source_name,
)

ROLE_ID = Qt.ItemDataRole.UserRole
ROLE_VISIBLE = Qt.ItemDataRole.UserRole + 1
CHECKED = Qt.CheckState.Checked
UNCHECKED = Qt.CheckState.Unchecked
SKEY = "quick_exporter/"
PKEY = "quick_exporter"


def _geom_label(layer):
    gt = layer.geometryType()
    for k, lab in ((Qgis.GeometryType.Point, "Punti"),
                   (Qgis.GeometryType.Line, "Linee"),
                   (Qgis.GeometryType.Polygon, "Poligoni")):
        if gt == k:
            return lab
    return "Vettore"


class MaskExportDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.settings = QgsSettings()
        self._feedback = None
        self._running = False
        self._mask_conn = None
        self._items = []
        self._first_load = True
        self.setWindowTitle("QuickExporter – Esporta layer su maschera")
        self.resize(780, 820)
        self._build_ui()
        self._load_settings()

    # ================================================================== UI
    def _build_ui(self):
        root = QVBoxLayout(self)

        # --- Maschera
        gb = QGroupBox("Maschera")
        f = QFormLayout(gb)
        self.cmb_mask = QgsMapLayerComboBox()
        try:
            self.cmb_mask.setFilters(Qgis.LayerFilter.PolygonLayer)
        except AttributeError:
            from qgis.core import QgsMapLayerProxyModel
            self.cmb_mask.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.cmb_mask.layerChanged.connect(self._on_mask_changed)
        f.addRow("Layer maschera:", self.cmb_mask)
        h = QHBoxLayout()
        self.chk_sel = QCheckBox("Usa solo gli elementi selezionati")
        self.lbl_sel = QLabel()
        self.lbl_sel.setStyleSheet("color: gray;")
        h.addWidget(self.chk_sel)
        h.addWidget(self.lbl_sel)
        h.addStretch()
        f.addRow(h)
        root.addWidget(gb)

        # --- Modalità
        gb = QGroupBox("Modalità di estrazione")
        v = QVBoxLayout(gb)
        self.rb_clip = QRadioButton("Ritaglio sulla maschera – le geometrie vengono tagliate sul perimetro")
        self.rb_sel = QRadioButton("Selezione sulla maschera – elementi interi, geometrie non modificate")
        self.rb_clip.setChecked(True)
        v.addWidget(self.rb_clip)
        v.addWidget(self.rb_sel)
        h = QHBoxLayout()
        h.addSpacing(24)
        h.addWidget(QLabel("Criterio:"))
        self.cmb_pred = QComboBox()
        self.cmb_pred.addItem("elementi che intersecano la maschera", PRED_INTERSECT)
        self.cmb_pred.addItem("elementi interamente contenuti nella maschera", PRED_WITHIN)
        self.cmb_pred.setEnabled(False)
        self.rb_sel.toggled.connect(self.cmb_pred.setEnabled)
        h.addWidget(self.cmb_pred)
        h.addStretch()
        v.addLayout(h)
        note = QLabel("I layer raster vengono sempre ritagliati sulla maschera (GeoTIFF).")
        note.setStyleSheet("color: gray;")
        v.addWidget(note)
        root.addWidget(gb)

        # --- Layer
        gb = QGroupBox("Layer da esportare")
        v = QVBoxLayout(gb)
        self.ed_filter = QLineEdit()
        self.ed_filter.setPlaceholderText("Filtra per nome o gruppo…")
        self.ed_filter.setClearButtonEnabled(True)
        self.ed_filter.textChanged.connect(self._apply_filter)
        v.addWidget(self.ed_filter)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Layer", "Tipo", "Gruppo"])
        self.tree.setRootIsDecorated(False)
        self.tree.setAlternatingRowColors(True)
        self.tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.tree.header().setSectionResizeMode(2, QHeaderView.ResizeMode.Interactive)
        self.tree.setColumnWidth(2, 200)
        self.tree.itemChanged.connect(self._update_count)
        v.addWidget(self.tree, 1)
        h = QHBoxLayout()
        for text, slot in (("Tutti", self._check_all), ("Nessuno", self._check_none),
                           ("Inverti", self._check_invert), ("Solo visibili", self._check_visible),
                           ("Aggiorna elenco", self.refresh_layers)):
            b = QPushButton(text)
            b.clicked.connect(slot)
            h.addWidget(b)
        h.addStretch()
        self.lbl_count = QLabel()
        h.addWidget(self.lbl_count)
        v.addLayout(h)
        root.addWidget(gb, 1)

        # --- Output
        gb = QGroupBox("Output")
        f = QFormLayout(gb)
        self.cmb_fmt = QComboBox()
        for k, (label, _d, _e) in FORMATS.items():
            self.cmb_fmt.addItem(label, k)
        self.cmb_fmt.currentIndexChanged.connect(self._on_fmt_changed)
        f.addRow("Formato:", self.cmb_fmt)
        self.fw_folder = QgsFileWidget()
        self.fw_folder.setStorageMode(QgsFileWidget.StorageMode.GetDirectory)
        f.addRow("Cartella:", self.fw_folder)
        self.ed_gpkg = QLineEdit("export_maschera.gpkg")
        f.addRow("Nome GeoPackage:", self.ed_gpkg)
        h = QHBoxLayout()
        self.ed_prefix = QLineEdit()
        self.ed_prefix.setPlaceholderText("prefisso")
        self.ed_suffix = QLineEdit()
        self.ed_suffix.setPlaceholderText("suffisso (es. _clip)")
        h.addWidget(self.ed_prefix)
        h.addWidget(QLabel("+ nome layer +"))
        h.addWidget(self.ed_suffix)
        f.addRow("Nomi output:", h)
        self.cmb_name = QComboBox()
        self.cmb_name.addItem("nome del file / tabella originale", "source")
        self.cmb_name.addItem("nome del layer nel pannello Layer", "layer")
        f.addRow("Nome base:", self.cmb_name)
        h = QHBoxLayout()
        self.chk_crs = QCheckBox("Riproietta in")
        self.crs_widget = QgsProjectionSelectionWidget()
        self.crs_widget.setEnabled(False)
        self.chk_crs.toggled.connect(self.crs_widget.setEnabled)
        h.addWidget(self.chk_crs)
        h.addWidget(self.crs_widget, 1)
        f.addRow("SR:", h)
        g = QGridLayout()
        self.chk_skip = QCheckBox("Salta i layer senza elementi nella maschera")
        self.chk_fix = QCheckBox("Correggi geometrie dei layer in ingresso")
        self.chk_style = QCheckBox("Copia lo stile dei layer di origine")
        self.chk_add = QCheckBox("Aggiungi i risultati al progetto")
        self.chk_over = QCheckBox("Sovrascrivi file/layer esistenti")
        for i, w in enumerate((self.chk_skip, self.chk_style, self.chk_add, self.chk_fix, self.chk_over)):
            g.addWidget(w, i // 2, i % 2)
        f.addRow(g)
        root.addWidget(gb)

        # --- Avanzamento
        self.progress = QProgressBar()
        self.progress.setFormat("%v / %m")
        root.addWidget(self.progress)
        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumHeight(130)
        root.addWidget(self.log_box)

        # --- Pulsanti
        h = QHBoxLayout()
        self.btn_open = QPushButton("Apri cartella")
        self.btn_open.clicked.connect(self._open_folder)
        h.addWidget(self.btn_open)
        h.addStretch()
        self.btn_run = QPushButton("Esporta")
        self.btn_run.setDefault(True)
        self.btn_run.clicked.connect(self._run)
        self.btn_cancel = QPushButton("Annulla")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self._cancel)
        self.btn_close = QPushButton("Chiudi")
        self.btn_close.clicked.connect(self.close)
        for b in (self.btn_run, self.btn_cancel, self.btn_close):
            h.addWidget(b)
        root.addLayout(h)

        self._on_fmt_changed()

    # ============================================================ settings
    def _load_settings(self):
        s = self.settings
        self.fw_folder.setFilePath(s.value(SKEY + "folder", "", type=str))
        i = self.cmb_fmt.findData(s.value(SKEY + "fmt", "gpkg_single", type=str))
        self.cmb_fmt.setCurrentIndex(max(i, 0))
        self.ed_gpkg.setText(s.value(SKEY + "gpkg_name", "export_maschera.gpkg", type=str))
        self.ed_prefix.setText(s.value(SKEY + "prefix", "", type=str))
        self.ed_suffix.setText(s.value(SKEY + "suffix", "", type=str))
        (self.rb_sel if s.value(SKEY + "mode", MODE_CLIP, type=str) == MODE_SELECT else self.rb_clip).setChecked(True)
        self.cmb_pred.setCurrentIndex(max(self.cmb_pred.findData(s.value(SKEY + "pred", PRED_INTERSECT, type=int)), 0))
        self.chk_skip.setChecked(s.value(SKEY + "skip", True, type=bool))
        self.chk_fix.setChecked(s.value(SKEY + "fix", False, type=bool))
        self.chk_style.setChecked(s.value(SKEY + "style", True, type=bool))
        self.chk_add.setChecked(s.value(SKEY + "add", True, type=bool))
        self.chk_over.setChecked(s.value(SKEY + "over", True, type=bool))
        self.cmb_name.setCurrentIndex(max(self.cmb_name.findData(s.value(SKEY + "name_from", "source", type=str)), 0))

    def _save_settings(self, o):
        s = self.settings
        s.setValue(SKEY + "folder", o.folder)
        s.setValue(SKEY + "fmt", o.fmt)
        s.setValue(SKEY + "gpkg_name", o.gpkg_name)
        s.setValue(SKEY + "prefix", o.prefix)
        s.setValue(SKEY + "suffix", o.suffix)
        s.setValue(SKEY + "mode", o.mode)
        s.setValue(SKEY + "pred", o.predicate)
        s.setValue(SKEY + "skip", o.skip_empty)
        s.setValue(SKEY + "fix", o.fix_input)
        s.setValue(SKEY + "style", o.copy_style)
        s.setValue(SKEY + "add", o.add_to_project)
        s.setValue(SKEY + "over", o.overwrite)
        s.setValue(SKEY + "name_from", o.name_from)
        # selezione layer e maschera salvate nel progetto
        prj = QgsProject.instance()
        prj.writeEntry(PKEY, "checked", self._checked_ids())
        prj.writeEntry(PKEY, "mask", o.mask_layer.id())
        prj.writeEntry(PKEY, "mask_selected", o.mask_selected_only)

    # ========================================================= layer list
    def refresh_layers(self):
        prj = QgsProject.instance()
        if self._first_load or not self._items:
            saved, _ok = prj.readListEntry(PKEY, "checked")
            prev = set(saved)
            mid, ok = prj.readEntry(PKEY, "mask")
            if ok and prj.mapLayer(mid):
                self.cmb_mask.setLayer(prj.mapLayer(mid))
            sel, ok = prj.readBoolEntry(PKEY, "mask_selected")
            if ok:
                self.chk_sel.setChecked(sel)
            self._first_load = False
        else:
            prev = set(self._checked_ids())

        self.tree.blockSignals(True)
        self.tree.clear()
        self._items = []
        for node in prj.layerTreeRoot().findLayers():
            layer = node.layer()
            if layer is None:
                continue
            if isinstance(layer, QgsVectorLayer):
                if not layer.isSpatial():
                    continue
                kind = _geom_label(layer)
            elif isinstance(layer, QgsRasterLayer) and layer.providerType() == "gdal":
                kind = "Raster"
            else:
                continue
            groups, p = [], node.parent()
            while p is not None and p.parent() is not None:
                groups.insert(0, p.name())
                p = p.parent()
            it = QTreeWidgetItem([layer.name(), kind, " / ".join(groups)])
            it.setIcon(0, QgsIconUtils.iconForLayer(layer))
            it.setData(0, ROLE_ID, layer.id())
            it.setData(0, ROLE_VISIBLE, node.isVisible())
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(0, CHECKED if layer.id() in prev else UNCHECKED)
            it.setToolTip(0, "Nome originale: %s\nSorgente: %s" % (source_name(layer), layer.source()))
            self.tree.addTopLevelItem(it)
            self._items.append(it)
        self.tree.blockSignals(False)
        self._apply_mask_state()
        self._apply_filter()
        self._update_sel_label()
        self._update_count()

    def _checked_ids(self):
        return [it.data(0, ROLE_ID) for it in self._items
                if it.checkState(0) == CHECKED and not it.isDisabled()]

    def _apply_mask_state(self):
        mask = self.cmb_mask.currentLayer()
        mid = mask.id() if mask else None
        self.tree.blockSignals(True)
        for it in self._items:
            is_mask = it.data(0, ROLE_ID) == mid
            it.setDisabled(is_mask)
            if is_mask:
                it.setCheckState(0, UNCHECKED)
                it.setToolTip(1, "Layer usato come maschera")
        self.tree.blockSignals(False)
        self._update_count()

    def _apply_filter(self, *_):
        t = self.ed_filter.text().strip().lower()
        for it in self._items:
            it.setHidden(bool(t) and t not in it.text(0).lower() and t not in it.text(2).lower())

    def _set_checks(self, fn):
        self.tree.blockSignals(True)
        for it in self._items:
            if it.isHidden() or it.isDisabled():
                continue
            it.setCheckState(0, CHECKED if fn(it) else UNCHECKED)
        self.tree.blockSignals(False)
        self._update_count()

    def _check_all(self):
        self._set_checks(lambda it: True)

    def _check_none(self):
        self._set_checks(lambda it: False)

    def _check_invert(self):
        self._set_checks(lambda it: it.checkState(0) != CHECKED)

    def _check_visible(self):
        self._set_checks(lambda it: bool(it.data(0, ROLE_VISIBLE)))

    def _update_count(self, *_):
        self.lbl_count.setText("%d di %d selezionati" % (len(self._checked_ids()), len(self._items)))

    # ================================================================ mask
    def _on_mask_changed(self, layer):
        if self._mask_conn is not None:
            try:
                self._mask_conn.selectionChanged.disconnect(self._update_sel_label)
            except (TypeError, RuntimeError):
                pass
        self._mask_conn = layer
        if layer is not None:
            layer.selectionChanged.connect(self._update_sel_label)
        self._update_sel_label()
        self._apply_mask_state()

    def _update_sel_label(self, *_):
        layer = self.cmb_mask.currentLayer()
        if layer is None:
            self.lbl_sel.setText("")
            return
        try:
            self.lbl_sel.setText("(%d selezionati su %d)" % (layer.selectedFeatureCount(), layer.featureCount()))
        except RuntimeError:
            self.lbl_sel.setText("")

    def _on_fmt_changed(self, *_):
        self.ed_gpkg.setEnabled(self.cmb_fmt.currentData() == "gpkg_single")

    # ================================================================= run
    def _log(self, msg):
        self.log_box.appendPlainText(msg)
        QCoreApplication.processEvents()

    def _progress(self, i, n, name):
        self.progress.setMaximum(n)
        self.progress.setValue(i)
        if name:
            self.progress.setFormat("%v / %m – " + name)
        else:
            self.progress.setFormat("%v / %m")
        QCoreApplication.processEvents()

    def _set_running(self, running):
        self._running = running
        for w in (self.btn_run, self.btn_close, self.tree, self.cmb_mask, self.cmb_fmt):
            w.setEnabled(not running)
        self.btn_cancel.setEnabled(running)

    def _cancel(self):
        if self._feedback:
            self._feedback.cancel()
            self._log("Annullamento in corso…")

    def _collect_options(self):
        o = ExportOptions()
        o.mask_layer = self.cmb_mask.currentLayer()
        o.mask_selected_only = self.chk_sel.isChecked()
        o.mode = MODE_SELECT if self.rb_sel.isChecked() else MODE_CLIP
        o.predicate = self.cmb_pred.currentData()
        o.fmt = self.cmb_fmt.currentData()
        o.folder = self.fw_folder.filePath().strip()
        o.gpkg_name = self.ed_gpkg.text().strip()
        o.prefix = self.ed_prefix.text()
        o.suffix = self.ed_suffix.text()
        o.target_crs = self.crs_widget.crs() if self.chk_crs.isChecked() else None
        o.skip_empty = self.chk_skip.isChecked()
        o.fix_input = self.chk_fix.isChecked()
        o.copy_style = self.chk_style.isChecked()
        o.add_to_project = self.chk_add.isChecked()
        o.overwrite = self.chk_over.isChecked()
        o.name_from = self.cmb_name.currentData()
        return o

    def _run(self):
        o = self._collect_options()
        prj = QgsProject.instance()
        layers = [prj.mapLayer(lid) for lid in self._checked_ids()]
        layers = [lyr for lyr in layers if lyr is not None]

        if o.mask_layer is None:
            return self._warn("Seleziona un layer maschera poligonale.")
        if o.mask_selected_only and o.mask_layer.selectedFeatureCount() == 0:
            return self._warn("Hai scelto di usare gli elementi selezionati, ma nel layer maschera non c'è nessuna selezione.")
        if not layers:
            return self._warn("Seleziona almeno un layer da esportare.")
        if not o.folder:
            return self._warn("Indica la cartella di output.")
        if o.target_crs is not None and not o.target_crs.isValid():
            return self._warn("Il sistema di riferimento di destinazione non è valido.")
        try:
            os.makedirs(o.folder, exist_ok=True)
        except OSError as e:
            return self._warn("Impossibile creare la cartella di output:\n%s" % e)

        self._save_settings(o)
        self.log_box.clear()
        mode_txt = "Ritaglio" if o.mode == MODE_CLIP else "Selezione (%s)" % self.cmb_pred.currentText()
        self._log("Modalità: %s – Formato: %s – %d layer" % (mode_txt, self.cmb_fmt.currentText(), len(layers)))

        self._feedback = QgsProcessingFeedback()
        self._feedback.progressChanged.connect(lambda _p: QCoreApplication.processEvents())
        self._set_running(True)
        results = []
        try:
            exporter = MaskExporter(o, self._feedback, self._log, self._progress)
            results = exporter.run(layers)
        except Exception as e:  # noqa: BLE001
            self._log("ERRORE: %s" % e)
        finally:
            self._set_running(False)
            self._feedback = None

        if o.add_to_project:
            self._add_to_project(results)

        ok = sum(1 for r in results if r["status"] == "ok")
        empty = sum(1 for r in results if r["status"] == "vuoto")
        err = sum(1 for r in results if r["status"] == "errore")
        skip = sum(1 for r in results if r["status"] == "saltato")
        self._log("\nCompletato: %d esportati, %d vuoti, %d saltati, %d errori." % (ok, empty, skip, err))
        level = Qgis.MessageLevel.Warning if err else Qgis.MessageLevel.Success
        self.iface.messageBar().pushMessage("QuickExporter", "%d layer esportati in %s" % (ok, o.folder), level, 6)

    def _add_to_project(self, results):
        outs = [r["out"] for r in results if r["status"] == "ok" and r["out"] is not None]
        if not outs:
            return
        prj = QgsProject.instance()
        group = prj.layerTreeRoot().insertGroup(0, "Export maschera %s" % datetime.now().strftime("%Y-%m-%d %H:%M"))
        for lyr in outs:
            prj.addMapLayer(lyr, False)
            group.addLayer(lyr)
        self.refresh_layers()

    def _open_folder(self):
        folder = self.fw_folder.filePath().strip()
        if folder and os.path.isdir(folder):
            QDesktopServices.openUrl(QUrl.fromLocalFile(folder))

    def _warn(self, msg):
        QMessageBox.warning(self, "QuickExporter", msg)

    def closeEvent(self, event):  # noqa: N802
        if self._running:
            event.ignore()
            return
        super().closeEvent(event)

    def reject(self):
        if not self._running:
            super().reject()
