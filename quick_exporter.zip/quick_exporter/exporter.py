# -*- coding: utf-8 -*-
"""Logica di esportazione: preparazione maschera, clip/selezione, scrittura file."""
import os
import re

from qgis.core import (
    QgsCoordinateTransform,
    QgsDataSourceUri,
    QgsFeatureRequest,
    QgsMapLayerStyle,
    QgsProcessingContext,
    QgsProcessingFeatureSourceDefinition,
    QgsProject,
    QgsProviderRegistry,
    QgsRasterLayer,
    QgsVectorFileWriter,
    QgsVectorLayer,
)
import processing

MODE_CLIP = "clip"
MODE_SELECT = "select"

# predicati di native:extractbylocation
PRED_INTERSECT = 0
PRED_WITHIN = 6

# chiave: (etichetta, driver OGR, estensione)
FORMATS = {
    "gpkg_single": ("GeoPackage – un unico file", "GPKG", ".gpkg"),
    "gpkg_multi": ("GeoPackage – un file per layer", "GPKG", ".gpkg"),
    "shp": ("ESRI Shapefile", "ESRI Shapefile", ".shp"),
    "geojson": ("GeoJSON", "GeoJSON", ".geojson"),
}


class ExportOptions:
    def __init__(self):
        self.mask_layer = None
        self.mask_selected_only = False
        self.mode = MODE_CLIP
        self.predicate = PRED_INTERSECT
        self.fmt = "gpkg_single"
        self.folder = ""
        self.gpkg_name = "export_maschera.gpkg"
        self.prefix = ""
        self.suffix = ""
        self.target_crs = None          # QgsCoordinateReferenceSystem o None
        self.skip_empty = True
        self.fix_input = False
        self.copy_style = True
        self.add_to_project = True
        self.overwrite = True
        self.name_from = "source"       # "source" = nome file/tabella originale, "layer" = nome nel pannello


def safe_name(name):
    s = re.sub(r"[^\w\-]+", "_", name.strip(), flags=re.UNICODE).strip("_")
    return s or "layer"


def source_name(layer):
    """Nome del dato originale: nome file (shp, tif, geojson…), nome tabella
    per GeoPackage/database; se non ricavabile, nome del layer nel pannello."""
    prov = layer.providerType()
    try:
        if prov in ("ogr", "gdal"):
            parts = QgsProviderRegistry.instance().decodeUri(prov, layer.source())
            lname = parts.get("layerName") or ""
            path = parts.get("path") or ""
            if lname:
                return lname
            if path:
                return os.path.splitext(os.path.basename(path))[0]
        elif prov in ("postgres", "spatialite", "oracle", "mssql", "hana"):
            table = QgsDataSourceUri(layer.source()).table()
            if table:
                return table
    except Exception:  # noqa: BLE001
        pass
    return layer.name()


class ExportCanceled(Exception):
    pass


class MaskExporter:
    def __init__(self, options, feedback, log, progress=None):
        self.o = options
        self.feedback = feedback
        self.log = log
        self.progress = progress or (lambda *a: None)
        self.project = QgsProject.instance()
        self.context = QgsProcessingContext()
        self.context.setProject(self.project)
        self.context.setInvalidGeometryCheck(QgsFeatureRequest.GeometryNoCheck)
        self._used_names = set()
        self._keep = []  # mantiene vivi i layer temporanei restituiti da processing
        self._gpkg_single_created = False

    # ------------------------------------------------------------------ util
    def _check_cancel(self):
        if self.feedback.isCanceled():
            raise ExportCanceled()

    def _run(self, alg, params):
        self._check_cancel()
        res = processing.run(alg, params, context=self.context, feedback=self.feedback)
        out = res["OUTPUT"]
        self._keep.append(out)
        return out

    def _base_name(self, layer):
        name = source_name(layer) if self.o.name_from == "source" else layer.name()
        return self.o.prefix + safe_name(name) + self.o.suffix

    def _unique(self, base):
        name, i = base, 1
        while name.lower() in self._used_names:
            name = "%s_%d" % (base, i)
            i += 1
        self._used_names.add(name.lower())
        return name

    def _out_folder(self):
        if self.o.fmt == "gpkg_single":
            return os.path.dirname(self._single_path())
        return self.o.folder

    def _single_path(self):
        name = self.o.gpkg_name.strip() or "export_maschera.gpkg"
        if not name.lower().endswith(".gpkg"):
            name += ".gpkg"
        return os.path.join(self.o.folder, name)

    def _reproject(self, src_crs):
        t = self.o.target_crs
        return t is not None and t.isValid() and t != src_crs

    # ----------------------------------------------------------------- mask
    def prepare_mask(self):
        m = self.o.mask_layer
        if self.o.mask_selected_only:
            if m.selectedFeatureCount() == 0:
                raise ValueError("Nessun elemento selezionato nel layer maschera.")
            src = QgsProcessingFeatureSourceDefinition(m.id(), True)
            self.log("Maschera: %s (%d elementi selezionati)" % (m.name(), m.selectedFeatureCount()))
        else:
            if m.featureCount() == 0:
                raise ValueError("Il layer maschera è vuoto.")
            src = m
            self.log("Maschera: %s (%d elementi)" % (m.name(), m.featureCount()))
        fixed = self._run("native:fixgeometries", {"INPUT": src, "OUTPUT": "TEMPORARY_OUTPUT"})
        mask = self._run("native:dissolve", {"INPUT": fixed, "FIELD": [], "OUTPUT": "TEMPORARY_OUTPUT"})
        return mask

    # ------------------------------------------------------------------ run
    def run(self, layers):
        results = []
        mask = self.prepare_mask()
        n = len(layers)
        for i, layer in enumerate(layers):
            self.progress(i, n, layer.name())
            r = {"name": layer.name(), "status": "", "path": "", "count": None, "out": None}
            try:
                self._check_cancel()
                if isinstance(layer, QgsRasterLayer):
                    self._export_raster(layer, mask, r)
                else:
                    self._export_vector(layer, mask, r)
            except ExportCanceled:
                r["status"] = "annullato"
                results.append(r)
                self.log("Esportazione annullata dall'utente.")
                break
            except Exception as e:  # noqa: BLE001
                r["status"] = "errore"
                self.log("  ✗ %s: %s" % (layer.name(), e))
            results.append(r)
        self.progress(n, n, "")
        return results

    # --------------------------------------------------------------- vector
    def _export_vector(self, layer, mask, r):
        src = layer
        if self.o.fix_input:
            src = self._run("native:fixgeometries", {"INPUT": layer, "OUTPUT": "TEMPORARY_OUTPUT"})

        if self.o.mode == MODE_CLIP:
            res = self._run("native:clip", {"INPUT": src, "OVERLAY": mask, "OUTPUT": "TEMPORARY_OUTPUT"})
        else:
            res = self._run("native:extractbylocation", {
                "INPUT": src,
                "PREDICATE": [self.o.predicate],
                "INTERSECT": mask,
                "OUTPUT": "TEMPORARY_OUTPUT",
            })

        count = res.featureCount()
        r["count"] = count
        if count == 0 and self.o.skip_empty:
            r["status"] = "vuoto"
            self.log("  – %s: nessun elemento nella maschera, saltato" % layer.name())
            return

        _, driver, ext = FORMATS[self.o.fmt]
        lname = self._unique(self._base_name(layer))

        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = driver
        opts.layerName = lname
        opts.fileEncoding = "UTF-8"
        if self._reproject(res.crs()):
            opts.ct = QgsCoordinateTransform(res.crs(), self.o.target_crs, self.project)

        if self.o.fmt == "gpkg_single":
            path = self._single_path()
            exists = os.path.exists(path)
            if exists and not self.o.overwrite:
                test = QgsVectorLayer("%s|layername=%s" % (path, lname), "t", "ogr")
                if test.isValid():
                    r["status"] = "saltato"
                    self.log("  – %s: layer '%s' già presente nel GeoPackage, saltato" % (layer.name(), lname))
                    return
            if exists:
                opts.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
            else:
                opts.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
            uri = "%s|layername=%s" % (path, lname)
        else:
            path = os.path.join(self.o.folder, lname + ext)
            if os.path.exists(path) and not self.o.overwrite:
                r["status"] = "saltato"
                self.log("  – %s: file già esistente, saltato" % os.path.basename(path))
                return
            opts.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
            uri = "%s|layername=%s" % (path, lname) if driver == "GPKG" else path

        err, msg, _newfile, _newlayer = QgsVectorFileWriter.writeAsVectorFormatV3(
            res, path, self.project.transformContext(), opts
        )
        if err != QgsVectorFileWriter.NoError:
            raise RuntimeError(msg or "errore di scrittura (%s)" % err)

        out = QgsVectorLayer(uri, lname, "ogr")
        if self.o.copy_style and out.isValid():
            self._copy_style(layer, out, driver, path, lname)

        r.update(status="ok", path=path, out=out if out.isValid() else None)
        self.log("  ✓ %s → %s (%d elementi)" % (layer.name(), os.path.basename(path) if self.o.fmt != "gpkg_single" else lname, count))

    # --------------------------------------------------------------- raster
    def _export_raster(self, layer, mask, r):
        lname = self._unique(self._base_name(layer))
        folder = self._out_folder()
        path = os.path.join(folder, lname + ".tif")
        if os.path.exists(path) and not self.o.overwrite:
            r["status"] = "saltato"
            self.log("  – %s: file già esistente, saltato" % os.path.basename(path))
            return
        params = {
            "INPUT": layer,
            "MASK": mask,
            "SOURCE_CRS": None,
            "TARGET_CRS": self.o.target_crs if self._reproject(layer.crs()) else None,
            "NODATA": None,
            "ALPHA_BAND": False,
            "CROP_TO_CUTLINE": True,
            "KEEP_RESOLUTION": True,
            "MULTITHREADING": True,
            "DATA_TYPE": 0,
            "OUTPUT": path,
        }
        self._check_cancel()
        processing.run("gdal:cliprasterbymasklayer", params, context=self.context, feedback=self.feedback)
        out = QgsRasterLayer(path, lname)
        if self.o.copy_style and out.isValid():
            self._copy_style(layer, out, None, path, lname)
        r.update(status="ok", path=path, out=out if out.isValid() else None)
        self.log("  ✓ %s → %s (raster ritagliato)" % (layer.name(), os.path.basename(path)))

    # ---------------------------------------------------------------- style
    def _copy_style(self, src, dst, driver, path, lname):
        try:
            st = QgsMapLayerStyle()
            st.readFromLayer(src)
            st.writeToLayer(dst)
            if driver == "GPKG":
                # salva lo stile nel GeoPackage come predefinito
                dst.saveStyleToDatabase(lname, "Stile copiato da %s" % src.name(), True, "")
            else:
                dst.saveNamedStyle(os.path.splitext(path)[0] + ".qml")
        except Exception as e:  # noqa: BLE001
            self.log("    (stile non copiato: %s)" % e)
