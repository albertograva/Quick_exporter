# QuickExporter

Plugin QGIS per esportare in un colpo solo più layer del progetto, ritagliati o selezionati su una maschera poligonale.

Autore: Alberto Grava - [www.albertograva.it](https://www.albertograva.it) - info@albertograva.it. Plugin sviluppato anche con l'ausilio di strumenti di intelligenza artificiale; progettazione, verifica e validazione a cura dell'autore.
Requisiti: QGIS ≥ 3.34

## Installazione
*Plugin › Gestisci e installa plugin… › Installa da ZIP* e scegli `quick_exporter.zip`.
Il comando compare nella barra strumenti e in *Vettore › QuickExporter*.

## Uso
1. **Maschera**: scegli il layer poligonale; spunta *Usa solo gli elementi selezionati* per usare solo la selezione corrente (il contatore si aggiorna in tempo reale, la finestra non è modale e puoi cambiare selezione in mappa a finestra aperta). Gli elementi della maschera vengono corretti e dissolti in un'unica geometria.
2. **Modalità**
   - *Ritaglio*: le geometrie vengono tagliate sul perimetro della maschera (`native:clip`).
   - *Selezione*: vengono estratti gli elementi interi (`native:extractbylocation`) che **intersecano** o che sono **interamente contenuti** nella maschera.
   - I raster (solo sorgenti file GDAL) vengono sempre ritagliati in GeoTIFF (`gdal:cliprasterbymasklayer`).
3. **Layer**: l'elenco segue l'ordine del pannello Layer, con il percorso dei gruppi. Filtro per nome/gruppo e pulsanti Tutti / Nessuno / Inverti / Solo visibili (agiscono solo sulle righe visibili dopo il filtro). Il layer maschera è escluso automaticamente.
4. **Output**: GeoPackage unico (un layer per tabella), GeoPackage per layer, Shapefile o GeoJSON; nome base dal **file/tabella originale** (shapefile, tif → nome file; GeoPackage/PostGIS → nome tabella) oppure dal nome nel pannello Layer, con prefisso/suffisso; riproiezione opzionale.
   Opzioni: salta i layer vuoti, copia lo stile (salvato come predefinito nel GeoPackage o come `.qml` accanto al file), aggiungi i risultati al progetto in un nuovo gruppo, correggi le geometrie in ingresso, sovrascrivi.

La selezione dei layer e la maschera vengono ricordate **nel progetto** (salvalo per conservarle); le altre opzioni restano nelle impostazioni di QGIS.

## Note
- In modalità GeoPackage unico i raster vengono scritti nella stessa cartella del file `.gpkg`.
- Se il ritaglio fallisce per geometrie non valide, riprova attivando *Correggi geometrie dei layer in ingresso*.
